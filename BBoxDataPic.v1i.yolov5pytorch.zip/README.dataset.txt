# BBoxDataPic > 2024-08-04 11:37am
https://universe.roboflow.com/croppednutritiondataset/bboxdatapic

Provided by a Roboflow user
License: CC BY 4.0

